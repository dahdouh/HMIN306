package analyse;

public class ClassAsString {
	
	public static String classAsString = 
	"public class Personne{ "
			+ "\npublic int age;"
			+ "\npublic String nom;"
			+ "\npublic String prenom;"
			+ "\npublic Personne(int age, String nom, String prenom) {"
				+ "\nthis.age = age;"
				+ "\nthis.nom = nom;"
				+ "\nthis.prenom = prenom;"
			+ "\n}"
			
	+ "\n}";
	
	/*public String getClassAsString() {
		return this.classAsString;
	}
	
	public void setClassAsString(String newValue) {
		this.classAsString = newValue ; 
	}*/
	
	/*public void AcceptVisit() {
		
	}*/

}