package com.supanadit.restsuite.component.input;
public class InputSearchCollection extends InputComponent {
    public InputSearchCollection() {
        setPlaceholder("Search Collection");
    }
}