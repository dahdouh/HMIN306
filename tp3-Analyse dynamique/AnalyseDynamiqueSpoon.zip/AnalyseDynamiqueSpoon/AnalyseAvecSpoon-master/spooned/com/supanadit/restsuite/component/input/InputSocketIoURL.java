package com.supanadit.restsuite.component.input;
public class InputSocketIoURL extends InputComponent {
    public InputSocketIoURL() {
        setPlaceholder("URL");
    }
}